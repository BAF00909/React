<?
$MESS ['MENU_ITEM_ACCESS_DENIED'] = "Доступ запрещен";
?>