<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Информация о ведомстве");
$APPLICATION->AddChainItem("Органы власти", "/services/");
$APPLICATION->AddChainItem("Информация о ведомстве");
?>		
			
<main id="main">
	<div id="nvxDepartmentInfo">
	<!--ko if: pageTitle-->
	<h1 data-bind="text: pageTitle, css: pageIcon()"></h1>
	<!--/ko-->
	<!--ko template: { name: templateId, data: templateModel }--><!--/ko-->
</div>


	
</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>