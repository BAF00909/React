<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Информация об услуге");
$APPLICATION->AddChainItem("Каталог услуг", "/services/");
$APPLICATION->AddChainItem("Информация об услуге");
?>		
			
<main id="main">
<div id="nvxServiceInfo">
	<!--ko if: pageTitle-->
	<h1 class="service-h1" data-bind="text: pageTitle, css: pageIcon()"></h1>
	<!--/ko-->
	<!--ko template: { name: templateId, data: templateModel }--><!--/ko-->
</div>
</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>