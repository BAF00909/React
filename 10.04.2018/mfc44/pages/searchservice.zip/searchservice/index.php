<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Информация об услуге");
$APPLICATION->AddChainItem("Каталог услуг", "/services/");
$APPLICATION->AddChainItem("Информация об услуге");
?>		
			
<main id="main">
<div id="nvxSearchService">
	<form class="search-area static" action="#">
		<div class="container">
			<div class="field-holder">
				<input type="search" class="form-control" placeholder="Введите название услуги" data-bind="value: serviceFilterModel().searchText, valueUpdate: 'afterkeydown', event: { keypress: serviceFilterModel().filterKeypress }">
				<button class="btn" data-bind="click: serviceFilterModel().filterKeypress" type="submit"><i class="icon-zoom_white_desk"></i></button>
			</div>
		</div>
	</form>
	
	<h1>Услуги</h1>
	<div data-bind="if: serviceFilterModel">
		<div data-bind="template: { name: 'Nvx.ReDoc.StateStructureServiceModule/Service/View/groupedPagerTemplate.tmpl.html', data: serviceFilterModel }"></div>
	</div>
</div>

			
</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>


