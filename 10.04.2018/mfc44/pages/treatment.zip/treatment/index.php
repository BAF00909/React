<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Информация об услуге");
$APPLICATION->AddChainItem("Каталог услуг", "/services/");
$APPLICATION->AddChainItem("Информация об услуге");
?>		
			
<main id="main">
	<div id="nvxTreatment">
		<div data-bind="template: { name: templateId, data: templateViewModel, if: templateViewModel }"/>
	</div>
</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>