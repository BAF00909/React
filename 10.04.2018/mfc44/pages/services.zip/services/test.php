<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Услуги");
?>	
	<script src='http://code.jquery.com/jquery-2.1.1.min.js'></script>

<ul class="accordion-list" id="nvxDepartments">
							
								<li class="open-close-open" data-bind="with: territorialDepartments">
									
										<a href="#" class="opener">Территориальный орган Федеральных органов исполнительной власти
												<i class="icon-arrow-circle">
												<span class="path1"></span>
												<span class="path2"></span>
												<span class="path3"></span>
											</i>
										</a>
									<div class="slide">
										<ul class="list" data-bind="foreach: subDepartments">
											<li data-bind="template: { name: 'Nvx/departmentsTreeItemView.tmpl.html', data: $data }"></li>
										</ul>
									</div>
								</li>
							
						</ul>
<script type="text/html" id="Nvx/departmentsTreeItemView.tmpl.html">
		<div class="holder"> 
		<a data-bind="attr: { href: link }"><img class="img" data-bind="css: id"><div class="text" data-bind="text: name"></div></a>
		</div>
		<ul class="sub-list" data-bind="foreach: subDepartments">
			<li data-bind="template: { name: 'Nvx/subDepartmentsTreeItemView.tmpl.html', data: $data }"></li>
		</ul>	
</script>

<script type="text/html" id="Nvx/subDepartmentsTreeItemView.tmpl.html">
		<li><a data-bind="text: name, attr: { href: link }"><i class="icon-arrow-right"></i></a></li>
</script>


<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>