<?
$aMenuLinks = Array(
	Array(
		"Для частных лиц", 
		"fiz/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Малому и среднему бизнесу", 
		"smallbusiness/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Для корпоративных клиентов", 
		"corp/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Финансовым организациям", 
		"financialorg/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>