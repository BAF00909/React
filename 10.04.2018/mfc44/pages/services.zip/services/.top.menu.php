<?
$aMenuLinks = Array(
	Array(
		"Каталог услуг", 
		"/services/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Помощь и поддержка", 
		"/support/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Оплата", 
		"/pay/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>