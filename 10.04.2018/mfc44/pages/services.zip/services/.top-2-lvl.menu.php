<?
$aMenuLinks = Array(
	Array(
		"Семья и дети", 
		"/services/semya-i-deti.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Паспорта, регистрации, визы", 
		"/services/pasporta-registratsii-vizy.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Транспорт и вождение", 
		"/services/transport-i-vozhdenie.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Образование", 
		"/services/obrazovanie.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>