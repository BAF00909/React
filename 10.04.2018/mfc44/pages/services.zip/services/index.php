<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Услуги");
?>		
		<!--  услуг -->
<h1 class="services-title">Каталог услуг</h1>
<div class="open-close dropdown change-userType" id="nvxUserSelectServices">					
						<a class="opener" href="#">
							<span data-bind="text: activeType"></span>
							<i class="icon-arrow-down"></i>
						</a>
						<div class="slide">
							<ul class="list-unstyled">
								<!-- ko foreach: availTypes -->
								<li>
									<a data-bind="click: $parent.changeType, text: title"></a>
								</li>
								<!-- /ko -->
							</ul>
						</div>
					</div>
<div id="nvxTripleCatalog">
	<!--div id="nvxSearchPanel"-->
		<form class="search-area static" data-bind="submit: goSearch ">
			<div class="container-center">
				<div class="field-holder">
					<input type="search" class="form-control" placeholder="Введите название услуги" data-bind="value: searchText">
					<button class="btn" type="submit" data-bind="click: goSearch">Поиск</button>
				</div>
			</div>
			
		</form>

	<span class="filter-itm filter-itm--out">
		<label class="filter-label"><input type="checkbox" data-bind="checked: onlyOnline"><span> Только электронные услуги</span></label>
	</span>

	<!--/div-->

	<main id="main">
		<div class="container-center tabs-area">
			
			<!-- nav-tabs -->
			<nav class="nav-tabset tabset">
				<ul> 
					<li class="active"><a href="#tab1">Категории услуг</a></li>
					<li><a href="#tab2">Органы власти</a></li>
					<li><a href="#tab3">Жизненные ситуации <!--<span class="tag-new">Новинка</span>--></a></li>
				</ul>
			</nav>
			
			<!-- tabs-holder -->
			<div class="tabs-holder">
				<div id="tab1" class="tab" data-bind="template: { name: 'nvxServiceList.tmpl.html', data: ServiceList }"></div>
				<div id="tab2" class="tab" data-bind="template: { name: 'nvxDepartments.tmpl.html', data: Departments }"></div>
				<div id="tab3" class="tab" data-bind="template: { name: 'nvxLifeSituations.tmpl.html', data: LifeSituations }"></div>
			</div>
		</div>
	</main>
</div>


		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>