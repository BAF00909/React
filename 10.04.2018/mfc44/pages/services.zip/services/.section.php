<?
$sSectionName = "Каталог услуг";
$arDirProperties = Array(

);
?>