<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Услуги");
?>		
			
<form class="search-area static" action="#">
			<div class="container">
				<div class="field-holder">
					<input type="search" class="form-control" placeholder="Введите название услуги или ведомства">
					<button class="btn" type="submit"><i class="icon-zoom_white_desk"></i></button>
				</div>
			</div>
		</form>

<?$APPLICATION->IncludeComponent(
	"bitrix:search.form", 
	"nvx-mainsearch", 
	array(
		"PAGE" => "#SITE_DIR#search/index.php",
		"USE_SUGGEST" => "Y",
		"COMPONENT_TEMPLATE" => "nvx-mainsearch"
	),
	false
);?>
<main id="main">
			<div class="container tabs-area">
				
				<!-- nav-tabs -->
				<nav class="nav-tabset tabset">
					<ul>
						<li class="active"><a href="#tab1">Категории услуг</a></li>
						<li><a href="#tab2">Органы власти</a></li>
						<li><a href="#tab3">Жизненные ситуации <span class="tag-new">Новинка</span></a></li>
					</ul>
				</nav>
				
					<!-- tabs-holder -->
				<div class="tabs-holder">
				
						<!-- tab1 -->
					<div id="tab1" class="row">

					</div>
						
						
					<div id="tab2">
					<script src="<?=SITE_TEMPLATE_PATH?>/../rpgu-main/Parts/Script/Start/startDepList.js"> </script>
												<!-- Перечень ведомств -->
						<ul class="accordion-list" id="nvxDepartments">
							
								<li class="open-close-open" data-bind="with: territorialDepartments">
									
										<a href="#" class="opener">Территориальный орган Федеральных органов исполнительной власти
												<i class="icon-arrow-circle">
												<span class="path1"></span>
												<span class="path2"></span>
												<span class="path3"></span>
												<span class="spoiler" data-bind="slideArrowBefore2: { 'contentClass': 'spoilerContent', 'hideClass': 'hide' }"></span>
											</i>
										</a>
									<div class="slide">
										<ul class="list" data-bind="foreach: subDepartments">
											<li data-bind="template: { name: 'Nvx/departmentsTreeItemView.tmpl.html', data: $data }"></li>
										</ul>
									</div>
								</li>
							
						</ul>
						<!-- Перечень ведомств -->
					</div>
					
					<!-- tab3 -->
					<div id="tab3" class="row">

					</div>
					
				</div>
			</div>
</main>
<script type="text/html" id="Nvx/departmentsTreeItemView.tmpl.html">
		<div class="holder"> 
		<a data-bind="attr: { href: link }"><img class="img" data-bind="css: id"><div class="text" data-bind="text: name"></div></a>
		</div>
		<ul class="sub-list" data-bind="foreach: subDepartments">
			<li data-bind="template: { name: 'Nvx/subDepartmentsTreeItemView.tmpl.html', data: $data }"></li>
		</ul>	
</script>

<script type="text/html" id="Nvx/subDepartmentsTreeItemView.tmpl.html">
		<li><a data-bind="text: name, attr: { href: link }"><i class="icon-arrow-right"></i></a></li>
</script>



		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>