<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Услуги");
?>		
		
<?$APPLICATION->IncludeComponent(
	"bitrix:search.form", 
	"nvx-mainsearch", 
	array(
		"PAGE" => "#SITE_DIR#search/index.php",
		"USE_SUGGEST" => "Y",
		"COMPONENT_TEMPLATE" => "nvx-mainsearch"
	),
	false
);?>
		<!--  услуг -->
<div id="nvxTripleCatalog">
	<!--div id="nvxSearchPanel"-->
		<form class="search-area static" data-bind="submit: goSearch ">
			<div class="container">
				<div class="field-holder">
					<input type="search" class="form-control" placeholder="Введите название услуги" data-bind="value: searchText">
					<button class="btn" type="submit" data-bind="click: goSearch"><i class="icon-zoom_white_desk"></i></button>
				</div>
			</div>
			<span class="filter-itm">
				<label class="filter-label"><input type="checkbox" data-bind="checked: onlyOnline"><span> Только электронные услуги</span></label>
			</span>
		</form>
	<!--/div-->

	<main id="main">
		<div class="container tabs-area">
			
			<!-- nav-tabs -->
			<nav class="nav-tabset tabset">
				<ul> 
					<li class="active"><a href="#tab1">Категории услуг</a></li>
					<li><a href="#tab2">Органы власти</a></li>
					<li><a href="#tab3">Жизненные ситуации <span class="tag-new">Новинка</span></a></li>
				</ul>
			</nav>
			
			<!-- tabs-holder -->
			<div class="tabs-holder">
				<div id="tab1" class="row" data-bind="template: { name: 'nvxServiceList.tmpl.html', data: ServiceList }"></div>
				<div id="tab2" class="row" data-bind="template: { name: 'nvxDepartments.tmpl.html', data: Departments }"></div>
				<div id="tab3" class="row" data-bind="template: { name: 'nvxLifeSituations.tmpl.html', data: LifeSituations }"></div>
			</div>
		</div>
	</main>
</div>


		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>