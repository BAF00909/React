<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Услуги");
?>		
		
<?$APPLICATION->IncludeComponent(
	"bitrix:search.form", 
	"nvx-mainsearch", 
	array(
		"PAGE" => "#SITE_DIR#search/index.php",
		"USE_SUGGEST" => "Y",
		"COMPONENT_TEMPLATE" => "nvx-mainsearch"
	),
	false
);?>
		
	<div id="nvxSearchPanel">
		<form class="search-area static" data-bind="submit: goSearch ">
			<div class="container">
				<div class="field-holder">
					<input type="search" class="form-control" placeholder="Введите название услуги" data-bind="value: searchText">
					<button class="btn" type="submit" data-bind="click: goSearch"><i class="icon-zoom_white_desk"></i></button>
				</div>

			</div>
			<span class="filter-itm">
				<label class="filter-label"><input type="checkbox" data-bind="checked: onlyOnline"><span> Только электронные услуги</span></label>
			</span>	
		</form>
	</div>

	<main id="main">
		<div class="container tabs-area">
			
			<!-- nav-tabs -->
			<nav class="nav-tabset tabset">
				<ul> 
					<li class="active"><a href="#tab1">Категории услуг</a></li>
					<li><a href="#tab2">Органы власти</a></li>
					<li><a href="#tab3">Жизненные ситуации <span class="tag-new">Новинка</span></a></li>
				</ul>
			</nav>
			
				<!-- tabs-holder -->
			<div class="tabs-holder">
			
					<!-- tab1 -->
				<div id="tab1" class="row">
					
					<div id="nvxServiceList">
						<!-- ko foreach: cats -->
							<article class="post-tab col-4">
								<header data-bind="click: goCategory">
									<img width="73" height="79" class="ico" alt="icon description" src="<?=SITE_TEMPLATE_PATH?>/../rpgu-main/Parts/Img/nut_arrow.svg" data-bind="css: groupId">
									<h2 data-bind="css: groupId"><a href="#" data-bind="text: groupTitle"></a></h2>
								</header>
								<ul class="list">
									<!-- ko foreach: list -->
									<li><a href="#" data-bind="html: name + '<span class=\'icon-arrow-right\'></span>', click: goPassport"></a></li>
									<!-- /ko -->
								</ul>
								<a class="btn primary" data-bind="click: goCategory">Все услуги</a>
							</article>
						<!-- /ko -->
							<!-- ko if: cats().length == 0 -->
							<h2>Для заданных критериев услуги отсутствуют</h2>
							<!-- /ko -->
					</div>
				</div>
					

				<div id="tab2">
					
	<!-- Перечень ведомств -->
					<div id="nvxDepartments">
						<ul class="accordion-list" >
							<li class="open-close-open" data-bind="with: territorialDepartments">
								<!--ko if: subDepartments.length > 0-->
								<a href="#" class="opener" data-bind="click: $parent.tdvisClick">
									Территориальный орган Федеральных органов исполнительной власти
									<i class="icon-arrow-circle"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
								</a>
								
								<div class="slide" data-bind="css: {'js-slide-hidden': $parent.tdvis }">
									<ul class="list" data-bind="foreach: subDepartments">
										<li data-bind="template: { name: 'Nvx/departmentsTreeItemView.tmpl.html', data: $data }"></li>
									</ul>
								</div>
								<!--/ko-->
							</li>
							<li class="open-close-open" data-bind="with: regionalDepartments">
								<!--ko if: subDepartments.length > 0-->
								<a href="#" class="opener" data-bind="click: $parent.rdvisClick">
									Региональные органы исполнительной власти
									<i class="icon-arrow-circle"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
								</a>
								
								<div class="slide" data-bind="css: {'js-slide-hidden': $parent.rdvis }">
									<ul class="list" data-bind="foreach: subDepartments">
										<li data-bind="template: { name: 'Nvx/departmentsTreeItemView.tmpl.html', data: $data }"></li>
									</ul>
								</div>
								<!--/ko-->
							</li>
							<li class="open-close-open" data-bind="with: municipalDepartments">
								<!--ko if: subDepartments.length > 0-->
								<a href="#" class="opener" data-bind="click: $parent.mdvisClick">
									Органы местного самоуправления
									<i class="icon-arrow-circle"><span class="path1"></span><span class="path2"></span><span class="path3"></span></i>
								</a>
								
								<div class="slide" data-bind="css: {'js-slide-hidden': $parent.mdvis }">
									<ul class="list" data-bind="foreach: subDepartments">
										<li data-bind="template: { name: 'Nvx/departmentsTreeItemView.tmpl.html', data: $data }"></li>
									</ul>
								</div>
								<!--/ko-->
							</li>
						</ul>
					</div>

					<script type="text/html" id="Nvx/departmentsTreeItemView.tmpl.html">
						<div class="holder">
							<a data-bind="attr: { href: link }, css: id">
								<img src="https://gu-st.ru/htdocs/img/structure-logo/img_RUSSIA.png" alt="" width="50" class="img">
								<div class="text" data-bind="text:name"></div>
							</a>
						</div>
						<!--ko if: subDepartments.length > 0 -->
						<ul class="sub-list" data-bind="foreach: subDepartments">
							<li data-bind="template: { name: 'Nvx/departmentsTreeItemViewSub.tmpl.html', data: $data }"></li>
						</ul>
						<!-- /ko -->
						
					</script>
					
					<script type="text/html" id="Nvx/departmentsTreeItemViewSub.tmpl.html">
						<a data-bind="text:name, attr: { href: link }, css: id"> </a>
						<!--ko if: subDepartments.length > 0 -->
						<ul class="sub-list" data-bind="foreach: subDepartments">
							<li data-bind="template: { name: 'Nvx/departmentsTreeItemViewSub.tmpl.html', data: $data }"></li>
						</ul>
						<!-- /ko -->
					</script>


				</div>
				
				<!-- tab3 -->
				<div id="tab3" class="row">
					
					<div id="nvxLifeSituations">
						<div>
							<div class="block categoriesServices" data-bind="template: { name: 'nvx/articleBlock.tmpl.html', data: serviceCategoriesBlock }"></div>
						</div>
					</div>
					<script type="text/html" id="nvx/articleBlock.tmpl.html">						
						<!-- ko foreach: items -->
						<article class="post-tab col-6">
							<div class="img-holder pull-left">
								<img src="<?=SITE_TEMPLATE_PATH?>/../rpgu-main/Parts/Img/pens-3.jpg">
							</div>
							<div class="post-content">
								<h2 class="post-title"><a data-bind="text: title, attr: { 'href': link }"></a></h2>
								<!--<p><a href="#" data-bind="text: name, attr: { 'href': link }"><i class="icon-arrow-right"></i></a></p>-->
							</div>
						</article>
						<!-- /ko -->
					</script>
				</div>
				
			</div>
		</div>			
	</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>