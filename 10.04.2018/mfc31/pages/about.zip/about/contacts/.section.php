<?
$sSectionName = "Контакты";
$arDirProperties = array(

);
?>