<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Правовая документация");
?><td width="50">
		<div class="pdf_icon">
		</div>
	</td>
	<td>
<a href="/qa/Download/Правовая документация.pdf">Правовая документация</a><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>