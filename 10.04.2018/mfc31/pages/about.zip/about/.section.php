<?
$sSectionName = "О МФЦ";
$arDirProperties = Array(
   "description" => "Информация о МФЦ"
);
?>