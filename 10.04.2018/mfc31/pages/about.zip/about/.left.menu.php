<?
$aMenuLinks = Array(
	Array(
		"Контакты", 
		"/about/mfc-contacts/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>