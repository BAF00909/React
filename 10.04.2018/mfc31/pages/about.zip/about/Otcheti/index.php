<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Отчеты");

CModule::IncludeModule("iblock");

$yvalue='15';
$q=$_GET["ELEMENT_ID"];
$arSelect = Array("ID","IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM");
$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ID"=>$q, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y");
$res = CIBlockElement::GetList(Array(), $arFilter, false, Array("nPageSize"=>50), $arSelect);
		  /* print("<pre>");
		  print_r($res);
		  print("</pre>"); */
while($ob = $res->GetNextElement())
{
 $el = $ob->GetFields();
}


  $array = array();
  $year=date('Y');
  while($year>2012){ 
		array_push ($array , $year);
		$year=$year-1;
	}

  foreach ($array as $y) {
  
	$yvalue='16';
    $arSelect = Array("ID", "IBLOCK_ID","NAME", "PROPERTY_*");
    $arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	
		 /*  print("<pre>");
		  print_r($res->arResult[0][ID]);
		  print("</pre>");  */
		 //echo count($res->arResult);
	if ($res->arResult[0]['ID']):?>
  <div class="panel panel-default">
	<div class="panel-heading">
      <h4 class="panel-title">
              <a class="section-title" data-toggle="collapse" data-parent="#accordion<?echo $year;?>" href="#Year<?echo $y;?>">
               <?echo $y;?>
              </a>
       </h4>
    </div>
	<div id="Year<?echo $y;?>" class="panel-collapse collapse">
      <div class="panel-body">
		<div class="panel-group" id="accordion<?echo $y;?>">

		
		<?

	$yvalue='16';
    $arSelect = Array("ID", "IBLOCK_ID","NAME", "PROPERTY_*"); ?>
	
    <?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"12", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	/* print("<pre>");
	print_r($res->arResult);
	print(count($res->arResult));
	print("</pre>"); */
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseDecember<?echo $y;?>">
						Декабрь
					</a>
				</h4>
			</div>
			<div id="collapseDecember<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"11", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseNovember<?echo $y;?>">
						Ноябрь
					</a>
				</h4>
			</div>
			<div id="collapseNovember<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"10", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseOctober<?echo $y;?>">
						Октябрь
					</a>
				</h4>
			</div>
			<div id="collapseOctober<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"9", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseSeptember<?echo $y;?>">
						Сентябрь
					</a>
				</h4>
			</div>
			<div id="collapseSeptember<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"8", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseAugust<?echo $y;?>">
						Август
					</a>
				</h4>
			</div>
			<div id="collapseAugust<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"7", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseJuly<?echo $y;?>">
						Июль
					</a>
				</h4>
			</div>
			<div id="collapseJuly<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"6", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseJune<?echo $y;?>">
						Июнь
					</a>
				</h4>
			</div>
			<div id="collapseJune<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"5", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseMay<?echo $y;?>">
						Май
					</a>
				</h4>
			</div>
			<div id="collapseMay<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"4", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseApril<?echo $y;?>">
						Апрель
					</a>
				</h4>
			</div>
			<div id="collapseApril<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"3", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseMarch<?echo $y;?>">
						Март
					</a>
				</h4>
			</div>
			<div id="collapseMarch<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"2", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseFebruary<?echo $y;?>">
						Февраль
					</a>
				</h4>
			</div>
			<div id="collapseFebruary<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
	<?
	$arFilter = Array("IBLOCK_ID"=>IntVal($yvalue), "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y", 'PROPERTY_YEAR'=>$y, 'PROPERTY_MONTH'=>"1", 'PROPERTY_TOWN'=>$el["NAME"]);
    $res = CIBlockElement::GetList(Array('id'=>'asc'), $arFilter, false, Array("nPageSize"=>300), $arSelect);
	if ($res->arResult[0]['ID']):?> 
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4 class="panel-title">
					<a data-toggle="collapse" data-parent="#accordion<?echo $y;?>" href="#collapseJanuary<?echo $y;?>">
						Январь
					</a>
				</h4>
			</div>
			<div id="collapseJanuary<?echo $y;?>" class="panel-collapse collapse">
				<div class="panel-body"><?
					while($ob = $res->GetNextElement()) {
						$arFields = $ob->GetFields();
						$arProps = $ob->GetProperties();
						?>
						<p><a href="<? print_r(CFile::GetPath($arProps["FILE"]["VALUE"]));?>" target="_blank"><?print_r($arFields["NAME"]);?></a></p>
						<?
					 }?>
				</div>
			</div>
		</div>
	<?endif;?>
			</div>
		</div>
	</div>
</div>
			<? endif;
	}
 ?> 
 	
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>