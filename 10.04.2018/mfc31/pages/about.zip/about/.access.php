<?
$PERM["contacts"]["*"]="X";
?>