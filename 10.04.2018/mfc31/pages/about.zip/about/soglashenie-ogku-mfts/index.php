<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Реестр соглашений");
?><table class="table table-striped">
<tbody>
<tr>
	<td width="50">
		<div class="pdf_icon">
		</div>
	</td>
	<td>
 <a href="/upload/docs/zakon/reestr soglasheni new.pdf">Реестр соглашений ОГКУ "МФЦ"</a>
	</td>
</tr>
</tbody>
</table>
 <a href="/upload/docs/zakon/Реестр соглашений филиалы 37.pdf"> </a> <a href="/upload/docs/templates/1D7.pdf"> </a><a href="/upload/docs/templates/1D7.pdf"></a>
<table class="table table-striped">
<tbody>
<tr>
	<td width="50">
		<div class="pdf_icon">
		</div>
	</td>
	<td>
 <a href="/upload/docs/zakon/reestr soglashenii filialy new.pdf">Реестр соглашений&nbsp;филиалы ОГКУ "МФЦ"</a>
	</td>
</tr>
</tbody>
</table>
 <a href="/upload/docs/templates/Реестр соглашений филиалы 37.pdf"> </a>
<table class="table table-striped">
<tbody>
<tr>
	<td width="50">
		<div class="pdf_icon">
		</div>
	</td>
	<td>
 <a href="/qa/Download/Реестр соглашений ТОСП ОГКУ МФЦ.pdf">Реестр соглашений ТОСП&nbsp;ОГКУ "МФЦ"</a>
	</td>
</tr>
</tbody>
</table><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>