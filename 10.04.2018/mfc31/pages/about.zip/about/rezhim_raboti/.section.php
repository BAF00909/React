<?
$sSectionName = "Режим работы";
$arDirProperties = array(
   "description" => "Информация о МФЦ"
);
?>