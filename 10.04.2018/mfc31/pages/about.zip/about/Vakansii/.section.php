<?
$sSectionName = "Вакансии";
$arDirProperties = array(
   "description" => "Информация о МФЦ"
);
?>