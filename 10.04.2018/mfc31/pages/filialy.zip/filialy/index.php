<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Филиалы");
?>
<div id="nvxMfcInfo">
	<!--ko template: { name: templateId, data: templateModel }--><!--/ko-->
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>