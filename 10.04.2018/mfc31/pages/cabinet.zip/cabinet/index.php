<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Персональная информация");
$APPLICATION->AddChainItem("Личный кабинет");
?>
			
<main id="main">
	<div class="tabs-area">
	
	<div id="nvxStartCreateFile"></div>

	<nav class="nav-tabset tabset">
		<ul> 
			<li class="active"><a href="#tab1">Персональная информация</a></li>
			<!--<li><a href="#tab2">Заявления</a></li>
			<li><a href="#tab3">Платежи</a></li>
			<li><a href="#tab4">Жалобы</a></li>-->
			<li><a href="#tab5">Запись на приём</a></li>
		</ul>
	</nav>
			
	<div>
		<div id="tab1" class="row">
			<div id="nvxCustomerInfo">
				<!-- Информация о заявителе. -->
				<!-- ko if: (isPhysical() && !isIndividual()) -->
				<div data-bind="template: { name: 'Nvx.ReDoc.Rpgu.PortalModule/Cabinet/View/customer/customer.tmpl.html', data: customerViewModel, if: customerViewModel }"></div>
				<!-- /ko -->
				<!-- ko if: (!isPhysical()) -->
				<div data-bind="template: { name: 'Nvx.ReDoc.Rpgu.PortalModule/Cabinet/View/customer/juridical.tmpl.html', data: customerViewModel, if: customerViewModel }"></div>
				<!-- /ko -->

				<!-- ko if: (isPhysical() && isIndividual()) -->
				<div data-bind="template: { name: 'Nvx.ReDoc.Rpgu.PortalModule/Cabinet/View/customer/individual.tmpl.html', data: customerViewModel, if: customerViewModel }"></div>
				<!-- /ko -->
			</div>
		</div>

		<div id="tab5" class="row">
			<div id="nvxLkReception">
				<div class="reception-redoc-form paddings">
					<p class="m-top-dbl" data-bind="text: commonInfoString, visible: commonInfoString() != null"></p>
					<!-- ko if: tickets().length > 0 -->
					<div class="reception-ticket-container">
						<!-- ko foreach: tickets -->
						<div class="reception-ticket-hrz m-btm">
							<div class="reception-ticket-hrz-1">
								<span data-bind="dateFormat: ticketDateTime, format: 'Simple'"></span>
								<br/>
								<!-- ko if: status -->
								<span class="opa">Статус: </span><span data-bind="text: status.recName"></span>
								<!-- /ko -->
							</div>
							<div class="reception-ticket-hrz-2">
								<!-- ko if: service -->
								<span class="opa">Услуга: </span><span data-bind="text: service.name"></span>
								<br/>
								<!-- /ko -->
								<!-- ko if: specialist && specialist.name -->
								<span class="opa">Специалист: </span><span data-bind="text: specialist.name"></span>
								<!-- /ko -->
							</div>
							<div class="reception-ticket-hrz-4 button btn primary" data-bind="click: $parent.printTicket">Печать</div>
							<div class="reception-ticket-hrz-3 button btn b-delete" data-bind="click: $parent.cancelReception, visible: canCancel">Отменить запись</div>
						</div>
						<!-- /ko -->
					</div>
					<!-- /ko -->
				</div>
			</div>
		</div>
	</div>
</div>
	
</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>