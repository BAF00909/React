<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Категории услуг");
$APPLICATION->AddChainItem("Категории услуг", "/services/");
$APPLICATION->AddChainItem("Перечень услуг");
?>		
			
<main id="main">
	
	<!-- Услуги для выбранной категории -->
	<div id="nvxCategoryServiceList">
		<h1 class="category-title" data-bind="text: title, css: keyId"></h1>
	
		<div class="search-area static">
			<div class="container-center">
				<div class="field-holder">
					<input type="search" class="form-control" placeholder="Введите название услуги" data-bind="value: searchText">
					<button class="btn" type="submit" data-bind="click: goSearch"><i class="icon-zoom_white_desk"></i>    Найти</button>
				</div>
			</div>
		</div>
		<span class="filter-itm">
				<label class="filter-label"><input type="checkbox" data-bind="checked: onlyOnline"><span> Только услуги онлайн</span></label>
		</span>

		<a data-bind="click: goCatalog" class="btn primary larr"><span></span>Вернуться в каталог</a>

		<div class="brdr"></div>
		
		<ul class="list category-service-list">
			<!-- ko foreach: services -->
			<li class="category-service-item">
				<a href="#" data-bind="click: $parent.goPassport">
					<span data-bind="text: name"></span>
				</a>
			</li>
			<!-- /ko -->
		</ul>
		<div class="btn primary pull-right" data-bind="visible: loadMoreVisible, click: loadList">Показать ещё</div>
		
	</div>
</main>
		
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>