<?
$sSectionName = "Законодательство";
$arDirProperties = array(
   "description" => "Информация о МФЦ"
);
?>