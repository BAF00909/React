<?
$sSectionName = "УРМ";
$arDirProperties = array(
   "description" => "Информация о МФЦ"
);
?>