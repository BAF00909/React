<?
$sSectionName = "Реестр соглашений";
$arDirProperties = array(

);
?>