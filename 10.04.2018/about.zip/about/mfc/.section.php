<?
$sSectionName = "О центре";
$arDirProperties = array(
   "description" => "Информация о МФЦ"
);
?>