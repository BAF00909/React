<?
$sSectionName = "Отчеты";
$arDirProperties = array(
   "description" => "Информация о МФЦ"
);
?>