<?
$sSectionName = "Правовая документация";
$arDirProperties = array(

);
?>