<?
$MESS ['T_NEWS_DETAIL_BACK'] = "Возврат к списку";
$MESS ['CATEGORIES'] = "Материалы по теме:";
?>